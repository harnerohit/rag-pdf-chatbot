---
name: Archivalist Editorial
colors:
  surface: '#faf9f8'
  surface-dim: '#dadad9'
  surface-bright: '#faf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f2'
  surface-container: '#eeeeed'
  surface-container-high: '#e9e8e7'
  surface-container-highest: '#e3e2e1'
  on-surface: '#1a1c1c'
  on-surface-variant: '#474741'
  inverse-surface: '#2f3130'
  inverse-on-surface: '#f1f0f0'
  outline: '#777770'
  outline-variant: '#c8c7bf'
  surface-tint: '#5f5e5b'
  primary: '#181916'
  on-primary: '#ffffff'
  primary-container: '#2d2d2a'
  on-primary-container: '#969490'
  inverse-primary: '#c8c6c2'
  secondary: '#5d604c'
  on-secondary: '#ffffff'
  secondary-container: '#e2e5cb'
  on-secondary-container: '#636652'
  tertiary: '#181916'
  on-tertiary: '#ffffff'
  tertiary-container: '#2d2d2a'
  on-tertiary-container: '#959490'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2dd'
  primary-fixed-dim: '#c8c6c2'
  on-primary-fixed: '#1c1c19'
  on-primary-fixed-variant: '#474743'
  secondary-fixed: '#e2e5cb'
  secondary-fixed-dim: '#c6c8b0'
  on-secondary-fixed: '#1a1d0d'
  on-secondary-fixed-variant: '#454836'
  tertiary-fixed: '#e4e2dd'
  tertiary-fixed-dim: '#c8c6c1'
  on-tertiary-fixed: '#1b1c19'
  on-tertiary-fixed-variant: '#474743'
  background: '#faf9f8'
  on-background: '#1a1c1c'
  surface-variant: '#e3e2e1'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 64px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  display-md:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  body-reading:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.7'
    letterSpacing: 0em
  body-ui:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0.01em
  label-caps:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.1em
  meta-data:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.4'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  gutter: 32px
  margin-mobile: 24px
  margin-desktop: 64px
  section-gap: 120px
  component-gap: 16px
---

## Brand & Style

The design system adopts a **Minimalist Editorial** style, treating the digital interface as a curated research notebook rather than a utility dashboard. The target audience consists of researchers, writers, and curators who value focus and intellectual clarity. 

The aesthetic is driven by generous whitespace, precision typography, and a "quiet" interface that recedes to prioritize content. High-end editorial influences manifest through dramatic typographic scales and a tactile, paper-like color palette. The emotional response should be one of calm authority and timelessness.

## Colors

The palette is rooted in natural, archival tones. **Warm White** serves as the primary canvas, providing a softer, more premium feel than pure white. **Graphite** is used for primary text and structural elements to maintain high legibility without the harshness of pure black.

**Stone** and **Slate** are utilized for secondary UI elements, borders, and metadata. **Muted Olive** is reserved for high-end accents, such as active states or key call-to-actions, appearing sparingly to maintain its premium impact. Contrast ratios must prioritize readability, especially for long-form research text.

## Typography

This design system uses **Geist** exclusively, leveraging its technical precision to create a modern editorial hierarchy. 

**Headlines** use tight tracking and significant scale to create a "dramatic" entry point for content. **Body text** is optimized for a "literary" experience with a generous 1.7 line height and an 18px base size for reading views. **Labels** use uppercase styling with increased letter spacing to provide clear structural markers without overwhelming the visual flow. All typographic elements should favor Graphite over pure black to maintain the premium, soft-contrast aesthetic.

## Layout & Spacing

The layout philosophy centers on a **Fixed Grid** with expansive margins to evoke the feeling of a wide-margined book. On desktop, a 12-column grid is used with a max-width of 1440px, flanked by 64px margins. 

Gutter widths are increased to 32px to ensure "breathing room" between content blocks. Section spacing is intentionally oversized (120px) to clearly demarcate different research contexts. Mobile layouts transition to a 4-column grid with 24px margins, maintaining the emphasis on vertical whitespace and typographic focus.

## Elevation & Depth

Depth is conveyed through **Tonal Layers** and extremely **Soft, Diffuse Shadows**. Surfaces do not "pop" off the page; instead, they sit subtly above the Warm White base.

Shadows (Elevation 1-2 only) use a large blur radius (16px+) with very low opacity (3-5%) tinted with the Slate color to avoid a "dirty" gray look. Low-contrast outlines using the Stone color are preferred over shadows for defining input fields and container boundaries. This creates a flat, paper-like stack rather than a deep 3D environment.

## Shapes

The shape language uses **Rounded (12px)** corners to soften the geometric precision of the typography. This "ROUND_TWELVE" logic applies to cards, buttons, and input fields, creating a modern, approachable feel that balances the rigor of the editorial type. Smaller components like chips use the same 12px radius, while very large containers may scale up to 24px (rounded-xl) to maintain visual harmony.

## Components

**Buttons:** Primary buttons are Graphite with Warm White text, utilizing 12px rounded corners and no shadow. Hover states subtly shift to Muted Olive. Secondary buttons use a Stone-colored outline.

**Input Fields:** Ghost-style inputs with a Stone bottom-border or a very light Stone stroke. Focus states use a 1px Graphite stroke.

**Cards:** Cards are defined by their content rather than heavy containers. Use the Warm White background with a subtle Stone stroke (1px) and an Elevation 1 shadow only.

**Icons:** Utilize 1.5pt thin-stroke, monochromatic icons. Icons should never use more than one color and should be sized consistently at 20px or 24px within a larger touch target.

**Research Notebook Elements:** Introduce "Marginalia" components—small text blocks in the Slate color that sit in the gutters or margins to provide secondary context without interrupting the main reading flow.